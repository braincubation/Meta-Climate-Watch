########################################################################## 
# Part A:  Temperature Anomaly Forecast using ARIMA+Prophet vs LSTM Model
# By:  Romeo Siquijor
# updated 12/20/2023
##########################################################################
library(readxl)  
library(forecast)
library(tidyverse)
library(dplyr)
library(ggplot2)
library(zoo)
library(uroot)
library(plotly)
library(corrplot)
library(carat)
library(keras)

################################################################################
# Part A:  Temperature Anomaly Using ARIMA + FB Prophet
################################################################################

setwd("C:/R/Project/final")

# Read the dataset
data = read.csv("temperature_data.csv")
print(data)
summary(data)
ts_data <- ts(data$Anomaly_monthly, start = c(data$Year[1], data$Month[1]), frequency = 12)

# Create additional time series objects (replace these with your actual data)
ts_annual <- ts(data$Anomaly_annual, start = c(data$Year[1], 1), frequency = 1)
ts_five_year <- ts(data$`Anomaly_Five-year`, start = c(data$Year[1], 1), frequency = 1)
ts_ten_year <- ts(data$`Anomaly_Ten-year`, start = c(data$Year[1], 1), frequency = 1)
ts_twenty_year <- ts(data$`Anomaly_Twenty-year`, start = c(data$Year[1], 1), frequency = 1)

# Plot the main time series
plot(ts_data, main = " Temperature Anomaly Time Series", col = "blue", cex.main = 1, ylab = "Temperature (in Celsius)")

# Add additional time series with different colors
lines(ts_annual, col = "red")
lines(ts_five_year, col = "green")
lines(ts_ten_year, col = "purple")
lines(ts_twenty_year, col = "orange")

# Add a legend
legend("topleft", legend = c("Monthly", "Annual", "Five-year", "Ten-year", "Twenty-year"), col = c("blue", "red", "green", "purple", "orange"), lty = 1)


# Label the last point for every line
text(length(ts_data), tail(ts_data, 1), labels = round(tail(ts_data, 1), 2), pos = 2, col = "blue")
text(length(ts_annual), tail(ts_annual, 1), labels = round(tail(ts_annual, 2), 2), pos = 2, col = "red")
text(length(ts_five_year), tail(ts_five_year, 1), labels = round(tail(ts_five_year, 2), 2), pos = 2, col = "green")
text(length(ts_ten_year), tail(ts_ten_year, 1), labels = round(tail(ts_ten_year, 2), 2), pos = 2, col = "purple")
text(length(ts_twenty_year), tail(ts_twenty_year, 1), labels = round(tail(ts_twenty_year, 2), 2), pos = 2, col = "orange")


# Display text in the console
cat("Original:", round(tail(ts_data, 1), 2), "\n", col = "blue")
cat("Annual Trend:", round(tail(ts_annual, 2), 2), "\n", col = "red")
cat("Five-Year Trend:", round(tail(ts_five_year, 2), 2), "\n", col = "green")
cat("Ten-Year Trend:", round(tail(ts_ten_year, 2), 2), "\n", col = "purple")
cat("Twenty-Year Trend:", round(tail(ts_twenty_year, 2), 2), "\n", col = "orange")


# Decompose the time series
decomp <- decompose(ts_data)
# Convert the decomposed data to a data frame
decomp_df <- data.frame(
  Date = as.Date(index(ts_data)),
  Month = factor(month(as.Date(index(ts_data)), label = TRUE), levels = month.abb),  # Extract and set correct order for month
  Original = as.numeric(ts_data),
  Trend = decomp$trend,
  Seasonal = decomp$seasonal,
  Random = decomp$random
)

# Order the data by Month
decomp_df <- decomp_df[order(decomp_df$Month), ]

# Check for missing values in the decomposed components
any(is.na(decomp$trend))
any(is.na(decomp$seasonal))
any(is.na(decomp$random))

# If there are missing values, consider imputing or removing them
decomp$trend <- na.omit(decomp$trend)
decomp$seasonal <- na.omit(decomp$seasonal)
decomp$random <- na.omit(decomp$random)


# Create the Time Series Autocorrelation Plot
ggAcf(ts_data, lag.max = 24) +
  theme_minimal() +
  scale_x_continuous(breaks = seq(0, 24, by = 2)) +
  labs(title = "Time Series Autocorrelation Plot",
       x = "Lag",
       y = "Autocorrelation") +
  theme(legend.position = "top", legend.title = element_blank()) +
  scale_color_manual(values = c("correlation" = "blue", "CI" = "red")) +
  geom_hline(yintercept = 0, linetype = "dashed", color = "gray") +
  geom_hline(yintercept = c(-1.96/sqrt(length(ts_data)), 1.96/sqrt(length(ts_data))),
             linetype = "dashed", color = "red") +
  geom_hline(yintercept = c(-2/sqrt(length(ts_data)), 2/sqrt(length(ts_data))),
             linetype = "dashed", color = "gray") +
  annotate("text", x = 25, y = 0.1, label = "95% CI", color = "red") +
  annotate("text", x = 25, y = -0.12, label = "99% CI", color = "gray")


# Melt the data for easier plotting
library(reshape2)
melted_data <- melt(data, id.vars = "Year")

# Create side-by-side bar graph
side_by_side_bar <- ggplot(melted_data, aes(x = Year, y = value, fill = variable)) +
  geom_bar(stat = "identity", position = "dodge", width = 1) +
  labs(title = "Side-by-Side Bar Graph",
       x = "Year",
       y = "Temperature Scale",
       fill = "Variable") +
  scale_fill_manual(values = c(
    "Anomaly_monthly" = "blue", "uncertainty_monthly" = "red",
    "Anomaly_annual" = "green", "uncertainty_annual" = "orange",
    "Anomaly_Five-year" = "purple", "uncertainty_Five-year" = "pink",
    "Anomaly_Ten-year" = "brown", "uncertainty_Ten-year" = "yellow",
    "Anomaly_Twenty-year" = "darkgreen", "uncertainty_Twenty-year" = "lightgreen"
  )) +
  ylim(0, 2) +  # Set the y-axis scale to 0-2
  theme_minimal()

# Display the side-by-side bar graph
print(side_by_side_bar)


# Fit an ARIMA model using auto.arima
arima_model <- auto.arima(ts_data)
#USING SEASONAL DIFFERENCE 
arima_model_1<- Arima(ts_data, order = c(2,1,1), seasonal = list(order = c(0,1,2), period = 12), include.drift = TRUE)

# Summary of the ARIMA model
summary(arima_model)
summary(arima_model_1)

# Check residuals
checkresiduals(arima_model)

# Diagnostic plots
tsdiag(arima_model)


# Wider grid search
grid_search <- expand.grid(p = 1:3, d = 1, q = 1:3, P = 1:3, D = 1, Q = 1:3)

ts_data <- na.omit(ts_data)


best_model <- auto.arima(
  ts_data,
  seasonal = TRUE,
  stepwise = FALSE,
  approximation = FALSE,
  trace = TRUE,
  xreg = NULL,
  stationary = FALSE,
  d = 1,  
  D = 1,
  num.cores = 1,
  test = "kpss",
  seasonal.test.args = list(lag = NULL),
  max.d = NA,
  allowmean = FALSE,
  start.p = 2,
  start.q = 2
)

# Fit the best ARIMA model
best_model <- Arima(ts_data, order = c(0, 1, 3), seasonal = list(order = c(2, 1, 0), period = 12))
summary(best_model)

# Forecast future values
forecast_values <- forecast(best_model, h = 24)  # Forecast can be adjusted to the horizon (h) as needed

# Plot the original time series
plot(ts_data, main = "ARIMA Forecast", xlab = "Year", ylab = "Temperature Anomaly", col = "blue",xlim = c(1850, 2050))

# Add the forecasted values to the plot
lines(forecast_values$mean, col = "red")

# Add a legend
legend("topleft", legend = c("Original", "Forecast"), col = c("blue", "red"), lty = c(1, 1))


library(prophet)
data$ds <- as.Date(paste(data$Year, data$Month, "1", sep="-"))
df_prophet <- data[, c("ds", "Anomaly_monthly")]
colnames(df_prophet) <- c("ds", "y")

# Initialize and fit the Prophet model with weekly and daily seasonality
model <- prophet(
  yearly.seasonality = TRUE,
  weekly.seasonality = TRUE,  # Enable weekly seasonality
  daily.seasonality = TRUE    # Enable daily seasonality
)

model <- add_seasonality(model, name = "custom", period = 60, fourier.order = 10)  # Assuming a periodicity of 5 years

# Fit the model
model_fit <- fit.prophet(model, df_prophet)

future <- make_future_dataframe(model_fit, periods = 12)  # Adjust periods as needed

forecast <- predict(model_fit, future)

summary(forecast)
summary(best_model)

# Plot the results with different colors
plot(model_fit, forecast, xlim = c(min(df_prophet$ds), max(future$ds)))

# Add actual data points
points(df_prophet$ds, df_prophet$y, col = "red", pch = 20)

# Add a legend
legend("topright", legend = c("Actual", "Predicted"),
       col = c("red", "blue"), pch = c(20, 1, 1), lty = c(0, 1, 1))


################################################################################
# Part B:  Temperature Anomaly Using LSTM
################################################################################

library(reticulate)
use_python("C:/Users/rmsiquijor/anaconda3/python.exe", required = TRUE)


train_data <- as.matrix(ts_data)
train_data <- matrix(train_data, ncol = 1) 

# Normalize the data (optional but often recommended for neural networks)
train_data <- scale(train_data)

# Create sequences for the LSTM model
sequence_length <- 12  # Assuming a seasonal period of 12
sequences <- matrix(0, nrow = length(train_data) - sequence_length + 1, ncol = sequence_length)

for (i in 1:(length(train_data) - sequence_length + 1)) {
  sequences[i,] <- train_data[i:(i + sequence_length - 1),]
}


# Split the data into input (X) and output (y)
X <- sequences[, 1:(sequence_length - 1)]
y <- sequences[, sequence_length]


# Reshape the input data to meet the LSTM input requirements
X <- array_reshape(X, c(dim(X), 1))


# Build the LSTM model
model <- keras_model_sequential()
model %>%
  layer_lstm(units = 50, input_shape = c(sequence_length - 1, 1)) %>%
  layer_dense(units = 1)

# Compile the model
model %>% compile(
  loss = 'mean_squared_error',
  optimizer = optimizer_adam(),
  metrics = c('mean_absolute_error')
)

# Train the model
model %>% fit(X, y, epochs = 100, batch_size = 32, verbose = 2)


# Predict the values using the trained LSTM model
predictions <- model %>% predict(X)

print(predictions)

# Plot the actual values
actual_values <- data$Anomaly_monthly
actual_dates <- seq(as.Date(paste(data$Year[1], "-", data$Month[1], "-01", sep = "")), by = "months", length.out = length(actual_values))
actual_data <- data.frame(date = actual_dates, actual = actual_values)

# Plot the predicted values
predicted_dates <- seq(as.Date(paste(data$Year[1], "-", data$Month[1] + sequence_length - 1, "-01", sep = "")), by = "months", length.out = length(predictions))
predicted_data <- data.frame(date = predicted_dates, predicted = predictions)

# Combine actual and predicted data for plotting
plot_data <- merge(actual_data, predicted_data, by = "date")

# Plotting
ggplot(plot_data, aes(x = date)) +
  geom_line(aes(y = actual, color = "Actual"), size = 1) +
  geom_line(aes(y = predicted, color = "Predicted"), size = 1, linetype = "dashed") +
  labs(title = "Actual vs Predicted Values",
       y = "Temp",
       x = "Year") +
  scale_color_manual(values = c("Actual" = "blue", "Predicted" = "red")) +
  theme_minimal()

################################################################################
#
# The LSTM (Long Short-Term Memory) model is good for its ability to capture 
# intricate patterns and complex interdependencies in time series data.  But 
# applying LSTM in our model exhibits a faster uptrend in temperature anomaly 
# compared to real observed data. I believe that this phenomenon arises from the 
# model's inherent characteristics and the complexities involved in training and 
# interpreting deep learning models.  I suspect that LSTM responded sensitively 
# to short-term fluctuations, leading to a quicker upward trend in its forecasts 
# compared to real-observed data.
#
# LSTM can be highly responsive to fluctuations, adjusting their internal states 
# based on recent observations. In the context of temperature anomaly, where 
# short-term variations can be influenced by various factors like weather patterns 
# or seasonal changes, the model might amplify these fluctuations, resulting in 
# a faster perceived uptrend.
#
# Based on my research, the complexity of the LSTM architecture considers multiple 
# layers and memory cells – which could capture and remember subtle patterns that 
# might be overlooked by simpler models. While this is a strength in capturing intricate 
# relationships, it can also lead to the model learning from noise or short-term 
# irregularities, potentially causing it to project a more rapid uptrend compared 
# to the actual observed data, as what we achieved in the model.
# It is important to note that the performance of deep learning models, including 
# LSTMs, heavily depends on the quality and quantity of the training data. If the 
# training data contains biases, outliers, or noise, the model might inadvertently 
# learn from these features, impacting its ability to generalize accurately to 
# unseen data.
#
# Interpreting and fine-tuning deep learning models like LSTMs can be challenging 
# due to their black-box nature. The intricate network of weights and connections 
# within the model makes it less transparent compared to traditional statistical 
# models like ARIMA. As a result, unexpected behaviors, such as a faster uptrend 
# in our model, might occur, and understanding the precise reasons behind these 
# behaviors can be complex.
################################################################################





